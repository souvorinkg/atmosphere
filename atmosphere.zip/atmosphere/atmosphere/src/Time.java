import java.util.Scanner;

public class Time
{
    private int hour;
    private int minute;
    private int second;

    public Time(int hour, int minute, int second)
    {
        this.hour = hour;
        this.minute = minute;
        this.second = second;
    }

    public void returnTime()
    {
        System.out.println("Searching for" + this.hour + ":" + this.minute + ":" + this.second);
    }
}