import java.util.Scanner;

public class Location {

    private int lattitude;
    private int longitude;
    
    public Location(int lattitude, int longitude) {
        this.lattitude = lattitude;
        this.longitude = longitude;
    }

    public void returnLocation() {
        System.out.println("Searching for" + this.lattitude + ":" + this.longitude);
    }
}
