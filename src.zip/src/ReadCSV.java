import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.HashMap;
public class ReadCSV
{
	public static void main(String[] args)
	{
		try
		{
			List< List<String> > data = new ArrayList<>();//list of lists to store data
			String file = "src/data_10sensors_1year.csv";//file path
			FileReader fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr);

			ArrayList<DataPoint> DataPointList = new ArrayList<>();
			
			int count = 0; //counting the number of lines, stop at 10, delete this line if you want to read the whole file

			//Reading until we run out of lines
			String line = br.readLine();
			line = br.readLine();//skipping the first line
			while((line != null) && (count < 10))
			{
				line = line.replaceAll("\"", "");
				line = line.replaceAll(" ", "");
				List<String> lineData = Arrays.asList(line.split(";"));//splitting lines
				if(lineData.size() == 5) {
					data.add(lineData);
					
					String[] date = lineData.get(0).split("T")[0].split("-");
					String[] time = lineData.get(0).split("T")[1].split(":");



					// System.out.print(convert(date[1]));
					// System.out.print(convert(date[2]));
					// System.out.print(convert(time[0]));

					Long month;
					Long day;
					Long hour;

					TimestampData timeStamp = new TimestampData(month = Long.valueOf(date[0]), day = Long.valueOf(date[2]), hour = Long.valueOf(time[0]));

					// System.out.print(timeStamp.month + " " + timeStamp.day + " " + timeStamp.hour + " ");

					DataPoint lineDataPoint = new DataPoint(timeStamp, new SensorData(lineData.get(1), 0, 0), lineData.get(2), lineData.get(3));
					count++; //incrementing the count, delete this line if you want to read the whole file
					System.out.println(lineDataPoint.timeStamp.month + " " + lineDataPoint.timeStamp.day + " " + lineDataPoint.timeStamp.hour + " " + lineDataPoint.sensorID.id + " " + lineDataPoint.sensorID.latitude + " " + lineDataPoint.sensorID.longitude + " " + lineDataPoint.attribute + " " + lineDataPoint.value);
					DataPointList.add(lineDataPoint);

				}
				count++; //incrementing the count, delete this line if you want to read the whole file
				line = br.readLine();
			}
			
			// printing the fetched data
			// for(List<String> list : data)
			// {
			// 	for(String str : list)
			// 		System.out.print(str + " ");
			// 	System.out.println();
			// }
			br.close();
		}
		catch(Exception e)
		{
			System.out.print(e);
		}

		
	}


	public static int convert(String str)
    {
        int val = 0;
        System.out.println("String = " + str);
  
        // Convert the String
        try {
            val = Integer.parseInt(str);
        }
        catch (NumberFormatException e) {
  
            // This is thrown when the String
            // contains characters other than digits
            System.out.println("Invalid String");
        }
        return val;
    }
}