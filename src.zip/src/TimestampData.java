public class TimestampData
{
    public long month;
    public long day;
    public long hour;

    public TimestampData(long month, long day, long hour) {
        this.month = month;
        this.day = day;
        this.hour = hour;
    }


}
