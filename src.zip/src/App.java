import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); 
            System.out.println("Enter 0 to see your options.");
            while (true) {
                System.out.print("Enter your option: ");
                int option = scanner.nextInt();
                switch (option) {
                    case 0:
                        System.out.println("1 - to see all data from a given time period");
                        System.out.println("2 - to see all data froma given location");
                        System.out.println("3 - to see sensors with similar data");
                        System.out.println("4 - to exit the application");
                        break;
                    case 1:
                        System.out.print("Enter hour: ");
                        int hour = scanner.nextInt();
                        System.out.print("Enter minute: ");
                        int minute = scanner.nextInt();
                        System.out.print("Enter second: ");
                        int second = scanner.nextInt();
                        Time time = new Time(hour, minute, second);
                        time.returnTime();
                        //compare data from a given time period
                        break;
                    case 2:
                        System.out.print("Enter lattitude: ");
                        int lattitude = scanner.nextInt();
                        System.out.print("Enter longitude: ");
                        int longitude = scanner.nextInt();
                        Location location = new Location(lattitude, longitude);
                        location.returnLocation();
                        //compare data from a given location
                        break;
                    case 3:
                        //compare sensors with similar data
                        break;
                    case 4:
                        System.out.println("Exiting the application...");
                        return;
                    default:
                        System.out.println("Invalid option");
                        break;
                }
            }
        }
    }
