public class DataPoint {
    public TimestampData timeStamp;
    public SensorData sensorID;
    public String attribute;
    public String value;

    public DataPoint(TimestampData timeStamp, SensorData sensorID, String attribute, String value) {
        this.timeStamp = timeStamp;
        this.sensorID = sensorID;
        this.attribute = attribute;
        this.value = value;
    }

    public void printDataPoint() {
        System.out.println(timeStamp.month + " " + timeStamp.day + " " + timeStamp.hour + " " + sensorID.id + " " + sensorID.latitude + " " + sensorID.longitude + " " + attribute + " " + value);
    }

    public TimestampData getTimestamp() {
        return timeStamp;
    }

    public SensorData getSensorID() {
        return sensorID;
    }

    public String getAttribute() {
        return attribute;
    }

    public String getValue() {
        return value;
    }

}
