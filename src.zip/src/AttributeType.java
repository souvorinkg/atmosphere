public class AttributeType {
    public String AttributeID;
    public String Unit;
    public String Description;

    public AttributeType(String AttributeID, String Unit, String Description) {
        this.AttributeID = AttributeID;
        this.Unit = Unit;
        this.Description = Description;
    }
}
